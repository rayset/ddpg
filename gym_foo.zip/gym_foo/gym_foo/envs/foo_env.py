import gym
import math
from gym import spaces
from gym.utils import seeding
import numpy as np
import scipy as sp
from scipy.linalg import block_diag



class FooEnv(gym.Env):
    metadata = {
        'render.modes': ['human', 'rgb_array'],
        'video.frames_per_second': 50
    }

    def __init__(self):
        self.A_1=[[0.5, 0.5],[0, 1] ]
        self.A_2=[[0.5, 0.5],[0, 1] ]
        self.A=block_diag(self.A_1,self.A_2)
        self.B_1=[[0],[1]]
        self.B_2=[[0],[1]]
        self.B=block_diag(self.B_1,self.B_2)
        self.Q=[[1,0,2,0],[1,0,0,2],[2,0,1,0],[0,2,1,0]]
        self.R=[[1,0],[0,3]]


        self.tau = 1  # seconds between state updates
        self.min_action = np.array([-0.5,-0.5,-0.5,-0.5])
        self.max_action = np.array([1.2,1.2,1.2,1.2])

        self.action_space = spaces.Box(
            low=self.min_action,
            high=self.max_action,
            shape=(4,)
        )
        self.observation_space = spaces.Box(-1000, 1000, shape=(4,))

        self.seed()
        self.viewer = None
        self.state = None

        self.steps_beyond_done = None

    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]




    def step(self, action):
      #  assert self.action_space.contains(action), \
      #      "%r (%s) invalid" % (action, type(action))
        done=0
        #print(action[0,0])
        x=self.state
        u= - block_diag(np.c_[action[0,0],action[0,1]],np.c_[action[1,0],action[1,1]]) @ x
        x_1=self.A @ x + self.B @ u
        self.state=x_1

        reward=- (np.transpose(x) @ self.Q @ x + np.transpose(u) @ self.R @ u)


        return np.array(self.state), reward, done, {}

    def reset(self):
        self.state=np.ones((4,1), dtype=np.float32)
        return self.state

    def close(self):
        if self.viewer:
            self.viewer.close()
